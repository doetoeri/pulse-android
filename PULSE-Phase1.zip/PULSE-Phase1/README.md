# PULSE Phase 1

Android (Kotlin + Jetpack Compose) local incoming-call **demo**. No real calls, AI audio, microphone capture, notifications or server yet.

## Build APK without a PC
1. Create a new GitHub repository, e.g. `pulse-android` (private recommended).
2. Upload **the contents of this ZIP** to the repository root, including `.github/workflows/android.yml`. GitHub's mobile web upload may not support whole directories; use GitHub Codespaces terminal or a Git client to commit the folder tree. In Codespaces: `unzip PULSE-Phase1.zip -d .` then `git add . && git commit -m 'Add Phase 1' && git push` (upload ZIP to Codespaces first).
3. Open GitHub > repository > Actions > Build Android APK > Run workflow. The workflow also runs on pushes to `main` or `master`.
4. When the build succeeds, open its run > Artifacts > `PULSE-Phase1-debug-apk` > download ZIP. Extract and install `app-debug.apk` on Android. Android may ask to allow installation from your file manager.

## What works
- In-app simulated incoming call, ringtone and vibration (when available)
- Accept / decline
- Active-call elapsed timer
- UI-only mute and speaker toggles (not actual audio routing)
- End / reset

## Architecture
- `CallState.kt`: sealed call states and future `VoiceEngine` interface.
- `CallViewModel.kt`: transitions, no network dependencies.
- `MainActivity.kt`: Compose UI and local ringtone/vibration.

## Next
Phase 2: actual voice capture, AI backend, TTS. Phase 3: remote push, authenticated call orchestration, Android call notifications. Keep API keys off device.

## Notes
Requires internet for first GitHub Actions dependency downloads. No permissions beyond vibration. The demo does not ring when the app is closed. This source has not been compiled in this environment; the Actions run is the first build validation.
