package com.pulse.assistant

import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

private val Navy = Color(0xFF101A2C)
private val Blue = Color(0xFF9DCBFF)
private val Soft = Color(0xFFC1CDDF)

class MainActivity : ComponentActivity() {
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else getSystemService(VIBRATOR_SERVICE) as Vibrator
        setContent {
            val vm: CallViewModel = viewModel()
            val state = vm.state
            LaunchedEffect(state is CallState.Ringing) {
                if (state is CallState.Ringing) startAlert() else stopAlert()
            }
            DisposableEffect(Unit) { onDispose { stopAlert() } }
            PulseScreen(state, vm)
        }
    }

    private fun startAlert() {
        stopAlert()
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, uri)?.also { it.play() }
        } catch (_: Exception) { /* Silent fallback on devices without a ringtone */ }
        try {
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 450, 300, 1200), 0))
        } catch (_: Exception) { /* Vibration is optional */ }
    }
    private fun stopAlert() {
        try { ringtone?.stop() } catch (_: Exception) {}
        ringtone = null
        try { vibrator?.cancel() } catch (_: Exception) {}
    }
    override fun onStop() {
        super.onStop()
        // Phase 1 does not implement background calling. Never ring invisibly.
        stopAlert()
    }
}

@Composable
private fun PulseScreen(state: CallState, vm: CallViewModel) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Color(0xFF1D2B41))) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("PULSE", color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("PHASE 01  ·  DEMO", color = Soft, fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Box(modifier = Modifier.size(104.dp).background(Color(0xFF273F5D), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Blue, modifier = Modifier.size(52.dp))
                    }
                    Text("PULSE", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.SemiBold)
                    when (state) {
                        CallState.Idle -> {
                            Text("선제적 AI 비서 · 통화 화면 테스트", color = Soft, textAlign = TextAlign.Center)
                            Text("아직 실제 AI나 원격 발신이 연결되지 않았어요.", color = Soft, fontSize = 12.sp, textAlign = TextAlign.Center)
                        }
                        is CallState.Ringing -> {
                            Text("수신 전화", color = Blue, fontSize = 18.sp)
                            Text(state.reason, color = Soft, textAlign = TextAlign.Center)
                        }
                        is CallState.Active -> {
                            Text("통화 중 · 데모 연결", color = Blue)
                            ElapsedTime(state.startedAt)
                            Text("음성 엔진은 Phase 2에서 연결됩니다.", color = Soft, fontSize = 12.sp)
                        }
                        is CallState.Ended -> Text(state.message, color = Soft)
                    }
                }
                when (state) {
                    CallState.Idle -> FilledTonalButton(onClick = vm::simulateIncomingCall) {
                        Icon(Icons.Default.PhoneInTalk, null); Spacer(Modifier.width(10.dp)); Text("테스트 전화 받기")
                    }
                    is CallState.Ringing -> Row(horizontalArrangement = Arrangement.spacedBy(50.dp)) {
                        CallButton(Icons.Default.CallEnd, "거절", Color(0xFFD54B5D), vm::decline)
                        CallButton(Icons.Default.Call, "수락", Color(0xFF279665), vm::accept)
                    }
                    is CallState.Active -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(25.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                            ToggleButton(if (state.muted) Icons.Default.MicOff else Icons.Default.Mic, if (state.muted) "음소거 해제" else "음소거", state.muted, vm::toggleMute)
                            ToggleButton(if (state.speaker) Icons.Default.VolumeUp else Icons.Default.VolumeDown, "스피커 (데모)", state.speaker, vm::toggleSpeaker)
                        }
                        CallButton(Icons.Default.CallEnd, "통화 종료", Color(0xFFD54B5D), vm::end)
                    }
                    is CallState.Ended -> Button(onClick = vm::reset) { Text("처음으로") }
                }
                Text("PULSE · LOCAL DEMO ONLY", color = Soft.copy(alpha = 0.6f), fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun ElapsedTime(startedAt: Long) {
    var now by remember(startedAt) { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(startedAt) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    val seconds = ((now - startedAt) / 1000).coerceAtLeast(0)
    Text("%02d:%02d".format(seconds / 60, seconds % 60), color = Color.White, fontSize = 30.sp)
}

@Composable
private fun CallButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledIconButton(onClick = onClick, modifier = Modifier.size(70.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = color)) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(29.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
private fun ToggleButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledTonalIconButton(onClick = onClick, modifier = Modifier.size(58.dp), colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = if (enabled) Blue else Color(0xFF2C405B))) {
            Icon(icon, contentDescription = label, tint = if (enabled) Navy else Color.White)
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = Soft, fontSize = 11.sp)
    }
}
