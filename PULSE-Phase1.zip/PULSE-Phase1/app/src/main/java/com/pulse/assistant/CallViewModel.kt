package com.pulse.assistant

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class CallViewModel : ViewModel() {
    var state: CallState by mutableStateOf(CallState.Idle)
        private set

    fun simulateIncomingCall() {
        if (state is CallState.Idle || state is CallState.Ended) {
            state = CallState.Ringing("오늘의 공부와 프로젝트 점검")
        }
    }
    fun accept() {
        if (state is CallState.Ringing) state = CallState.Active(System.currentTimeMillis())
    }
    fun decline() {
        if (state is CallState.Ringing) state = CallState.Ended("통화를 거절했어요")
    }
    fun end() {
        if (state is CallState.Active) state = CallState.Ended("통화가 종료되었어요")
    }
    fun toggleMute() {
        val active = state as? CallState.Active ?: return
        state = active.copy(muted = !active.muted)
    }
    fun toggleSpeaker() {
        val active = state as? CallState.Active ?: return
        state = active.copy(speaker = !active.speaker)
    }
    fun reset() { state = CallState.Idle }
}
