package com.pulse.assistant

sealed interface CallState {
    data object Idle : CallState
    data class Ringing(val reason: String) : CallState
    data class Active(val startedAt: Long, val muted: Boolean = false, val speaker: Boolean = false) : CallState
    data class Ended(val message: String) : CallState
}

/** Phase 2 integration seam. An AI implementation can own audio capture and playback here. */
interface VoiceEngine {
    suspend fun startSession()
    suspend fun stopSession()
    suspend fun setMicrophoneMuted(muted: Boolean)
}
